import 'package:flutter/material.dart';

double CustomHeight(context){
  return MediaQuery.of(context).size.height;
}double CustomWidth(context){
  return MediaQuery.of(context).size.width;
}